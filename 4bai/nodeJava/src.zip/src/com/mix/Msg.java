package com.mix;

/**
 * Created by tingkl on 2017/7/28.
 */
public class Msg {
    Boolean success;
    String msg;

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
